<?php
return array(
	 'PIC_UPLOADS' => 'http://hwlbz.scau.edu.cn/AquaticProduct/Public/uploads/',
    
);