<?php
namespace Home\Model;
use Think\Model;

class TestModel extends Model {
    
    public function test(){
    	echo test;
    }
}

